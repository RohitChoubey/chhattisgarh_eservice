import React from 'react'
import Navnew from './Navnew.css'
import { Link } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap/dist/css/bootstrap.css';



export default function Navbar() {
  return (
    <div>
        <div className="nav">
            <input type="checkbox" id="nav-check" />
            <div className="m-auto nav-header">
                <div className="nav-title">
                Forest Department
                </div>
            </div>
            <div className="nav-btn">
                <label htmlFor="nav-check">
                <span></span>
                <span></span>
                <span></span>
                </label>
            </div>
            
            <div className="mx-md-auto nav-links">
                <Link to ="/dashboard">Dashboard</Link>
                <Link to ="http://stackoverflow.com/users/4084003/" rel="noreferrer">GIS Based Application Summary</Link>
                <Link to ="https://in.linkedin.com/in/jonesvinothjoseph" rel="noreferrer">RO Inspection Reports</Link>
                <Link to ="https://codepen.io/jo_Geek/" rel="noreferrer">Login</Link>
                <Link to ="https://jsfiddle.net/user/jo_Geek/" rel="noreferrer">JsFiddle</Link>
            </div>
        </div>
    </div>
  )
}
