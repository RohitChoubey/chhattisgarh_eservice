import React from 'react';

export default function Dashboard() {
  return (
    <>
    <center>
      <h3>Dashboard</h3>
    </center>
    </>
  );
}
